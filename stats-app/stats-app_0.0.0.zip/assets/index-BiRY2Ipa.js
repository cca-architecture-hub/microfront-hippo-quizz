import { importShared } from './__federation_fn_import-n0cJJfEl.js';
import App, { j as jsxRuntimeExports } from './__federation_expose_StatsApp-jF3HbF3p.js';
import { r as requireReactDom } from './index-CIt7cilh.js';

var client = {};

var hasRequiredClient;

function requireClient () {
	if (hasRequiredClient) return client;
	hasRequiredClient = 1;
	var m = requireReactDom();
	{
	  client.createRoot = m.createRoot;
	  client.hydrateRoot = m.hydrateRoot;
	}
	return client;
}

var clientExports = requireClient();

const {StrictMode} = await importShared('react');
clientExports.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) })
);
