import { g as getDefaultExportFromCjs } from './_commonjsHelpers-B85MJLTf.js';
import { r as requireReact } from './index-BsZuZKGy.js';

var reactExports = requireReact();
const index = /*@__PURE__*/getDefaultExportFromCjs(reactExports);

export { index as default };
